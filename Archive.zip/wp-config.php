<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link http://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'u476541734_pro');

/** MySQL database username */
define('DB_USER', 'u476541734_pro');

/** MySQL database password */
define('DB_PASSWORD', 'carter15');

/** MySQL hostname */
define('DB_HOST', 'mysql.nixiweb.com');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '-N,UlcEkm/j,);:_?>:Exu|gNda{g$`mHY84OPu&+^|+Z`J9T>U[F@lB7ei^M,O4');
define('SECURE_AUTH_KEY',  ']5$J7AfsO5u*X#zNJPG-Fp| M^Xs/HWM+}Yt?IJry]#-gPWP!+nXt7l2rM]*+Ud2');
define('LOGGED_IN_KEY',    ')P*xa;J#T+,1M#ThuM8WFb,gN72;2_uKOnEY~Rlj~`+&=#Hk0GZYI}qIq Xy/H8d');
define('NONCE_KEY',        '|J(i90LT(2{?|jW@a+JuHZpGg)i2C|X<-5~wU}&=Rvq5g(DXbz-VTG,l(JwaJma{');
define('AUTH_SALT',        'nlsqD+|z|;O2FAwtqFh9D$%5Vm,oDK*k 77NB+=TU[[/2mSO{NoSl2$-uGY_wY7O');
define('SECURE_AUTH_SALT', 'PR5B*q 9wKP-=qO=5nK H7]+Q03g&8u^5cp^*9Bnh;(xG+r[9/v)L),7{/Q|w`jD');
define('LOGGED_IN_SALT',   'b!7Mm6<]&f~v*4{8`Mw2+x-g-I*HmwC:{!+s*mT*cI<@u1[.s+tw$>;jdr*c$@29');
define('NONCE_SALT',       'l^![rt,8B]z*8*y:Fi/iioY@-(y@!_l5cO7vu9BR85?$OarjxZ H.-}i>N)5RHx`');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);


/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
